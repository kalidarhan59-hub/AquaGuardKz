import React, { useState, useRef } from 'react';
import { Background, BackgroundRef } from './components/Background';
import { i18n, Lang } from './i18n';
import { cities, City } from './data';
import { MapSection } from './components/MapSection';
import { CityModal } from './components/CityModal';
import { AnimatePresence, motion } from 'motion/react';
import { Menu, Map as MapIcon, Search, Phone, Mail, MessageCircle, Instagram, X } from 'lucide-react';

type Page = 'home' | 'map' | 'cities' | 'about' | 'contact';

const Footer = ({ lang, openPolicy, openTerms }: { lang: Lang, openPolicy: () => void, openTerms: () => void }) => {
  const t = i18n[lang];
  return (
    <footer className="w-full glass-panel border-t border-accent/30 mt-12 py-8 px-6 md:px-12 flex flex-col md:flex-row justify-between items-center gap-8 relative z-10">
      <div className="text-center md:text-left">
        <div className="text-2xl font-bold neon-text mb-2 tracking-wider">AquaGuard KZ</div>
        <div className="text-gray-400 text-sm">© 2026 AquaGuard KZ. {t.footer_rights}</div>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4 sm:gap-8 text-sm text-gray-300 text-center">
        <button onClick={openPolicy} className="hover:text-accent transition-colors">{t.footer_privacy}</button>
        <button onClick={openTerms} className="hover:text-accent transition-colors">{t.footer_terms}</button>
      </div>
      
      <div className="text-center md:text-right text-sm text-gray-300 flex flex-col items-center md:items-end gap-2">
        <div className="flex items-center gap-2"><Phone size={16} className="text-accent"/> +7 778 224 74 06</div>
        <div className="flex items-center gap-2"><Mail size={16} className="text-accent"/> info@aquaguard.kz</div>
        <div className="flex gap-4 justify-center md:justify-end mt-2">
           <a href="#" className="text-gray-400 hover:text-accent transition-colors"><MessageCircle size={20} /></a>
           <a href="#" className="text-gray-400 hover:text-accent transition-colors"><Instagram size={20} /></a>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  const [lang, setLang] = useState<Lang>('kz');
  const [page, setPage] = useState<Page>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedCity, setSelectedCity] = useState<City | null>(null);
  const [policyModalOpen, setPolicyModalOpen] = useState(false);
  const [termsModalOpen, setTermsModalOpen] = useState(false);
  const bgRef = useRef<BackgroundRef>(null);

  const navigate = (p: Page) => {
    setPage(p);
    setMobileMenuOpen(false);
    bgRef.current?.triggerRain();
  };

  const t = i18n[lang];

  return (
    <>
      <Background ref={bgRef} />

      {/* Header */}
      <nav className="fixed w-full z-50 glass-panel py-3 px-4 md:px-8 flex justify-between items-center">
        <div className="flex items-center gap-4 cursor-pointer group" onClick={() => navigate('home')}>
          <div className="drop-logo">
            <svg className="drop-logo-inner" viewBox="0 0 100 100">
              <path d="M15,55 Q35,35 75,45 Q95,65 65,85 Q25,75 15,55 Z" fill="none" stroke="#ffffff" strokeWidth="4" filter="drop-shadow(0 0 4px #fff)"/>
            </svg>
          </div>
          <span className="text-2xl md:text-3xl font-bold neon-text tracking-wider hidden sm:block">AquaGuard KZ</span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden lg:flex gap-8 items-center font-medium text-sm uppercase tracking-widest">
          <button onClick={() => navigate('home')} className={`hover:text-accent transition-all ${page === 'home' ? 'text-accent neon-text' : ''}`}>{t.nav_home}</button>
          <button onClick={() => navigate('map')} className={`hover:text-accent transition-all ${page === 'map' ? 'text-accent neon-text' : ''}`}>{t.nav_map}</button>
          <button onClick={() => navigate('cities')} className={`hover:text-accent transition-all ${page === 'cities' ? 'text-accent neon-text' : ''}`}>{t.nav_cities}</button>
          <button onClick={() => navigate('about')} className={`hover:text-accent transition-all ${page === 'about' ? 'text-accent neon-text' : ''}`}>{t.nav_about}</button>
          <button onClick={() => navigate('contact')} className={`hover:text-accent transition-all ${page === 'contact' ? 'text-accent neon-text' : ''}`}>{t.nav_contact}</button>
        </div>

        <div className="flex items-center gap-4">
          <select 
            value={lang}
            onChange={(e) => setLang(e.target.value as Lang)}
            className="bg-darker border border-accent text-white rounded-lg px-3 py-2 outline-none neon-box cursor-pointer font-bold"
          >
            <option value="kz">🇰🇿 KZ</option>
            <option value="ru">🇷🇺 RU</option>
            <option value="en">🇬🇧 EN</option>
          </select>
          <button className="hidden md:block neon-button px-6 py-2 rounded-full font-bold text-sm uppercase tracking-wider">
            {t.report}
          </button>
          
          {/* Mobile Menu Toggle */}
          <button className="lg:hidden text-accent text-3xl neon-text" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            <Menu />
          </button>
        </div>
      </nav>

      {/* Mobile Nav */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-[72px] left-0 w-full glass-panel flex flex-col p-6 gap-6 z-40 border-b border-accent"
          >
            <button onClick={() => navigate('home')} className="text-xl text-left">{t.nav_home}</button>
            <button onClick={() => navigate('map')} className="text-xl text-left">{t.nav_map}</button>
            <button onClick={() => navigate('cities')} className="text-xl text-left">{t.nav_cities}</button>
            <button onClick={() => navigate('about')} className="text-xl text-left">{t.nav_about}</button>
            <button onClick={() => navigate('contact')} className="text-xl text-left">{t.nav_contact}</button>
            <button className="neon-button px-6 py-3 rounded-full font-bold w-full mt-4">{t.report}</button>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="pt-[72px] h-screen w-full overflow-y-auto flex flex-col">
        <div className="flex-1">
          <AnimatePresence mode="wait">
            {page === 'home' && (
              <motion.section 
                key="home"
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
                className="min-h-[calc(100vh-72px)] flex flex-col items-center justify-center text-center px-4 relative"
              >
                <div className="max-w-5xl z-10 py-20">
                  <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold mb-6 neon-text leading-tight">{t.title}</h1>
                  <p className="text-xl md:text-3xl mb-4 text-gray-200 font-light">{t.slogan}</p>
                  <p className="text-lg md:text-xl mb-12 text-accent font-mono">{t.subtitle}</p>
                  
                  <div className="flex gap-6 flex-col sm:flex-row justify-center">
                    <button onClick={() => navigate('map')} className="neon-button px-10 py-5 rounded-full text-lg font-bold uppercase tracking-widest flex items-center justify-center gap-3">
                      <MapIcon className="w-6 h-6" />
                      <span>{t.btn_map}</span>
                    </button>
                    <button onClick={() => navigate('cities')} className="neon-box bg-darker bg-opacity-50 px-10 py-5 rounded-full text-lg font-bold uppercase tracking-widest hover:bg-accent hover:bg-opacity-20 flex items-center justify-center gap-3">
                      <Search className="w-6 h-6" />
                      <span>{t.btn_search}</span>
                    </button>
                  </div>
                </div>
              </motion.section>
            )}

            {page === 'map' && (
              <motion.section 
                key="map"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="h-[calc(100vh-72px)] relative"
              >
                <MapSection lang={lang} onCityClick={setSelectedCity} />
              </motion.section>
            )}

            {page === 'cities' && (
              <motion.section 
                key="cities"
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
                className="min-h-[calc(100vh-72px)] p-6 md:p-12"
              >
                <h2 className="text-4xl md:text-5xl font-bold neon-text mb-12 text-center pt-8">{t.cities_title}</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 max-w-7xl mx-auto">
                  {cities.filter(c => c.isMain).map(c => {
                    const status = c.r === 0 ? t.norm : c.r === 1 ? t.warn : t.danger;
                    const color = c.r === 0 ? 'success' : c.r === 1 ? 'warning' : 'danger';
                    return (
                      <div 
                        key={c.id} 
                        className="neon-box glass-panel p-6 rounded-xl cursor-pointer hover:scale-105 transition-transform"
                        onClick={() => setSelectedCity(c)}
                      >
                        <h3 className="text-xl font-bold mb-2">{c.n}</h3>
                        <div className="flex items-center gap-2">
                          <span className={`w-3 h-3 rounded-full bg-${color} shadow-[0_0_10px_var(--color-${color})]`}></span>
                          <span className="text-gray-300">{status}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.section>
            )}

            {page === 'about' && (
              <motion.section 
                key="about"
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
                className="min-h-[calc(100vh-72px)] p-6 md:p-12 flex flex-col items-center justify-center"
              >
                <h2 className="text-4xl md:text-6xl font-bold neon-text mb-12">{t.about_title}</h2>
                <div className="glass-panel p-8 md:p-12 rounded-3xl max-w-4xl text-lg md:text-xl leading-relaxed neon-box text-center">
                  <div className="drop-logo mx-auto mb-8 transform scale-150">
                    <svg className="drop-logo-inner" viewBox="0 0 100 100">
                      <path d="M15,55 Q35,35 75,45 Q95,65 65,85 Q25,75 15,55 Z" fill="none" stroke="#ffffff" strokeWidth="4"/>
                    </svg>
                  </div>
                  <p className="mb-6 text-accent font-semibold">{t.about_text1}</p>
                  <p className="mb-6 text-gray-300">{t.about_text2}</p>
                  <p className="text-gray-300">{t.about_text3}</p>
                </div>
              </motion.section>
            )}

            {page === 'contact' && (
              <motion.section 
                key="contact"
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
                className="min-h-[calc(100vh-72px)] p-6 md:p-12 flex flex-col items-center justify-center"
              >
                <h2 className="text-4xl md:text-6xl font-bold neon-text mb-12">{t.contact_title}</h2>
                <div className="glass-panel p-8 md:p-12 rounded-3xl max-w-2xl text-center neon-box w-full">
                  <p className="text-xl mb-8 text-gray-200">{t.contact_text}</p>
                  <div className="flex flex-col gap-6 items-center">
                    <div className="flex items-center gap-4 text-2xl"><Phone className="text-accent" size={32}/> +7 778 224 74 06</div>
                    <div className="flex items-center gap-4 text-2xl"><Mail className="text-accent" size={32}/> info@aquaguard.kz</div>
                    <div className="flex gap-6 mt-6">
                      <button className="neon-button p-4 rounded-full"><MessageCircle size={28}/></button>
                      <button className="neon-button p-4 rounded-full"><Instagram size={28}/></button>
                    </div>
                  </div>
                </div>
              </motion.section>
            )}
          </AnimatePresence>
        </div>
        
        {/* Footer only shows on scrollable pages, not map */}
        {page !== 'map' && <Footer lang={lang} openPolicy={() => setPolicyModalOpen(true)} openTerms={() => setTermsModalOpen(true)} />}
      </main>

      <AnimatePresence>
        {selectedCity && (
          <CityModal 
            city={selectedCity} 
            lang={lang} 
            onClose={() => setSelectedCity(null)} 
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {policyModalOpen && (
          <div className="fixed inset-0 bg-black/80 z-[9999] flex items-center justify-center p-4 backdrop-blur-sm">
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="glass-panel neon-box rounded-2xl w-full max-w-2xl p-8 relative">
              <button onClick={() => setPolicyModalOpen(false)} className="absolute top-4 right-4 text-gray-400 hover:text-white"><X size={28} /></button>
              <h2 className="text-3xl font-bold neon-text mb-6">{t.footer_privacy}</h2>
              <div className="text-gray-300 space-y-4 h-64 overflow-y-auto pr-4">
                <p>Бұл Құпиялылық саясаты (Privacy Policy) AquaGuard KZ платформасының пайдаланушы деректерін қалай жинайтынын, пайдаланатынын және қорғайтынын түсіндіреді.</p>
                <p>1. Деректерді жинау: Біз тек қызмет сапасын жақсарту үшін қажетті анонимді статистикалық деректерді жинаймыз.</p>
                <p>2. Деректерді қорғау: Барлық жиналған ақпарат заманауи шифрлау әдістерімен қорғалған.</p>
                <p>3. Үшінші тараптар: Біз пайдаланушылардың жеке деректерін үшінші тараптарға сатпаймыз немесе бермейміз.</p>
                <p>Осы саясатқа қатысты сұрақтарыңыз болса, info@aquaguard.kz электрондық поштасына хабарласыңыз.</p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {termsModalOpen && (
          <div className="fixed inset-0 bg-black/80 z-[9999] flex items-center justify-center p-4 backdrop-blur-sm">
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="glass-panel neon-box rounded-2xl w-full max-w-2xl p-8 relative">
              <button onClick={() => setTermsModalOpen(false)} className="absolute top-4 right-4 text-gray-400 hover:text-white"><X size={28} /></button>
              <h2 className="text-3xl font-bold neon-text mb-6">{t.footer_terms}</h2>
              <div className="text-gray-300 space-y-4 h-64 overflow-y-auto pr-4">
                <p>Осы Қолдану шарттары (Terms of Service) AquaGuard KZ платформасын пайдалану ережелерін белгілейді.</p>
                <p>1. Жалпы ережелер: Платформаны пайдалану арқылы сіз осы шарттармен келісесіз.</p>
                <p>2. Ақпараттың дәлдігі: Біз ұсынылған деректердің барынша дәл болуын қамтамасыз етуге тырысамыз, бірақ олардың 100% дәлдігіне кепілдік бермейміз.</p>
                <p>3. Жауапкершілікті шектеу: AquaGuard KZ платформадағы ақпаратты пайдаланудан туындаған кез келген тікелей немесе жанама шығындар үшін жауап бермейді.</p>
                <p>4. Өзгерістер: Біз осы шарттарды кез келген уақытта алдын ала ескертусіз өзгерту құқығын өзімізде қалдырамыз.</p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
