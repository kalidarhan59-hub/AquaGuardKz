import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, useMap } from 'react-leaflet';
import L from 'leaflet';
import { cities, City } from '../data';
import { Lang, i18n } from '../i18n';

const createIcon = (r: number, isMain: boolean) => {
  const size = isMain ? 16 : 10;
  const colorClass = r === 0 ? 'marker-success' : r === 1 ? 'marker-warning' : 'marker-danger';
  return L.divIcon({
    className: `custom-marker ${colorClass}`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2]
  });
};

const MapController = ({ center, zoom }: { center: [number, number], zoom: number }) => {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);
  return null;
};

interface MapSectionProps {
  lang: Lang;
  onCityClick: (city: City) => void;
}

export const MapSection: React.FC<MapSectionProps> = ({ lang, onCityClick }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<City[]>([]);
  const [mapCenter, setMapCenter] = useState<[number, number]>([48.019, 66.923]);
  const [mapZoom, setMapZoom] = useState(5);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchQuery(val);
    if (!val) {
      setSearchResults([]);
      return;
    }
    const matches = cities.filter(c => 
      c.n.toLowerCase().includes(val.toLowerCase()) || 
      c.region.toLowerCase().includes(val.toLowerCase())
    ).slice(0, 8);
    setSearchResults(matches);
  };

  const handleSelectCity = (c: City) => {
    setMapCenter([c.lat, c.lng]);
    setMapZoom(10);
    setSearchQuery('');
    setSearchResults([]);
    onCityClick(c);
  };

  return (
    <div className="w-full h-full relative">
      <MapContainer 
        center={mapCenter} 
        zoom={mapZoom} 
        zoomControl={false} 
        className="w-full h-full z-0"
      >
        <TileLayer
          attribution='&copy; OpenStreetMap contributors &copy; CARTO'
          url='https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
          subdomains='abcd'
          maxZoom={19}
        />
        <MapController center={mapCenter} zoom={mapZoom} />
        {cities.map((c) => (
          <Marker 
            key={c.id} 
            position={[c.lat, c.lng]} 
            icon={createIcon(c.r, c.isMain)}
            eventHandlers={{
              click: () => onCityClick(c)
            }}
          />
        ))}
      </MapContainer>

      <div className="absolute top-6 left-6 z-[400] glass-panel p-5 rounded-2xl w-80 neon-box">
        <div className="relative mb-4">
          <input 
            type="text" 
            value={searchQuery}
            onChange={handleSearch}
            className="w-full bg-dark border border-accent rounded-lg py-3 px-4 text-white outline-none focus:shadow-[0_0_15px_#00d4ff] transition-all" 
            placeholder={i18n[lang].search_ph} 
          />
          {searchResults.length > 0 && (
            <div className="absolute w-full bg-darker border border-accent rounded-lg mt-1 max-h-60 overflow-y-auto z-50">
              {searchResults.map(c => (
                <div 
                  key={c.id} 
                  className="p-3 hover:bg-accent hover:bg-opacity-20 cursor-pointer border-b border-gray-700"
                  onClick={() => handleSelectCity(c)}
                >
                  {c.n}
                </div>
              ))}
            </div>
          )}
        </div>
        
        <div className="space-y-3 bg-dark p-4 rounded-lg border border-gray-700">
          <div className="flex items-center gap-3">
            <span className="w-4 h-4 rounded-full bg-success shadow-[0_0_10px_#00c853]"></span> 
            <span className="font-medium">{i18n[lang].norm}</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="w-4 h-4 rounded-full bg-warning shadow-[0_0_10px_#f59e0b]"></span> 
            <span className="font-medium">{i18n[lang].warn}</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="w-4 h-4 rounded-full bg-danger shadow-[0_0_10px_#ef4444]"></span> 
            <span className="font-medium">{i18n[lang].danger}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
