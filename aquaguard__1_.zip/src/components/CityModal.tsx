import React, { useMemo } from 'react';
import { City } from '../data';
import { Lang, i18n } from '../i18n';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, Filler } from 'chart.js';
import { motion } from 'motion/react';
import { X, MapPin, Users, Info, ExternalLink, BookOpen, CloudRain } from 'lucide-react';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, Filler);

interface CityModalProps {
  city: City;
  lang: Lang;
  onClose: () => void;
}

export const CityModal: React.FC<CityModalProps> = ({ city, lang, onClose }) => {
  const t = i18n[lang];
  const statusTxt = city.r === 0 ? t.norm : city.r === 1 ? t.warn : t.danger;
  const color = city.r === 0 ? '#00c853' : city.r === 1 ? '#f59e0b' : '#ef4444';

  const params = useMemo(() => [
    { k: 'param_nh4', v: (Math.random()*2).toFixed(2), max: 1.5 },
    { k: 'param_no3', v: (Math.random()*50).toFixed(1), max: 45 },
    { k: 'param_fe', v: (Math.random()*0.5).toFixed(2), max: 0.3 },
    { k: 'param_hard', v: (Math.random()*10).toFixed(1), max: 7 },
    { k: 'param_ph', v: (6.5 + Math.random()*2).toFixed(1), max: 8.5 },
    { k: 'param_turb', v: (Math.random()*3).toFixed(1), max: 1.5 },
    { k: 'param_mic', v: (Math.random()*10).toFixed(0), max: 5 }
  ], [city.id]);

  const chartData14 = useMemo(() => {
    return Array.from({length: 14}, () => Math.max(0, city.r * 20 + (Math.random()-0.5)*20));
  }, [city.id]);

  const chartData5y = useMemo(() => {
    return Array.from({length: 5}, () => Math.max(0, city.r * 15 + (Math.random()-0.5)*15));
  }, [city.id]);

  const createChartData = (dataPoints: number[], labels: string[]) => ({
    labels,
    datasets: [{
      label: 'AQI',
      data: dataPoints,
      borderColor: '#00d4ff',
      backgroundColor: 'rgba(0, 212, 255, 0.1)',
      borderWidth: 2,
      fill: true,
      tension: 0.4,
      pointBackgroundColor: color,
      pointBorderColor: '#fff'
    }]
  });

  const chartOptions = {
    responsive: true, 
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#888' } },
      x: { grid: { display: false }, ticks: { color: '#888' } }
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 z-[9999] flex items-center justify-center p-4 backdrop-blur-sm">
      <motion.div 
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="glass-panel neon-box rounded-2xl w-full max-w-5xl max-h-[90vh] overflow-y-auto p-6 relative"
      >
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors">
          <X size={28} />
        </button>
        
        <div className="mb-6 border-b border-accent/30 pb-6">
          <h3 className="text-3xl md:text-4xl font-bold neon-text mb-3">{city.n}</h3>
          
          <div className="flex flex-wrap gap-4 mb-4">
            <div className="flex items-center gap-2 text-gray-300 bg-darker/50 px-3 py-1.5 rounded-lg border border-gray-700">
              <MapPin size={18} className="text-accent" />
              <span><span className="font-semibold text-white">{t.region}:</span> {city.region}</span>
            </div>
            <div className="flex items-center gap-2 text-gray-300 bg-darker/50 px-3 py-1.5 rounded-lg border border-gray-700">
              <Users size={18} className="text-accent" />
              <span><span className="font-semibold text-white">{t.population}:</span> ~{city.pop}</span>
            </div>
            <div 
              className="inline-flex items-center px-4 py-1.5 rounded-lg text-sm font-bold text-white"
              style={{ backgroundColor: color, boxShadow: `0 0 15px ${color}` }}
            >
              {statusTxt}
            </div>
          </div>

          <div className="flex items-start gap-3 text-gray-300 bg-darker/50 p-4 rounded-lg border border-gray-700 mb-4">
            <Info size={20} className="text-accent shrink-0 mt-0.5" />
            <p><span className="font-semibold text-white">{t.desc}:</span> {city.desc}</p>
          </div>

          {city.links && (
            <div className="flex flex-wrap gap-4 mt-4">
              {city.links.official && (
                <a href={city.links.official} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-accent hover:text-white transition-colors bg-darker/50 px-3 py-2 rounded-lg border border-accent/30 hover:border-accent">
                  <ExternalLink size={16} /> Ресми сайт (gov.kz)
                </a>
              )}
              {city.links.wiki && (
                <a href={city.links.wiki} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-accent hover:text-white transition-colors bg-darker/50 px-3 py-2 rounded-lg border border-accent/30 hover:border-accent">
                  <BookOpen size={16} /> Wikipedia
                </a>
              )}
              {city.links.meteo && (
                <a href={city.links.meteo} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-accent hover:text-white transition-colors bg-darker/50 px-3 py-2 rounded-lg border border-accent/30 hover:border-accent">
                  <CloudRain size={16} /> Қазгидромет
                </a>
              )}
            </div>
          )}
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <div className="bg-darker p-5 rounded-xl border border-accent/50 lg:col-span-1">
            <h4 className="font-bold mb-4 text-accent border-b border-gray-700 pb-2">Көрсеткіштер</h4>
            <div className="space-y-3">
              {params.map((p, i) => {
                const isBad = parseFloat(p.v) > p.max;
                return (
                  <div key={i} className="flex justify-between border-b border-gray-800 pb-2">
                    <span className="text-gray-300">{(t as any)[p.k]}</span>
                    <span className={`font-mono font-bold ${isBad ? 'text-danger' : 'text-success'}`}>
                      {p.v} <span className="text-xs text-gray-500">/ {p.max}</span>
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="lg:col-span-2 flex flex-col gap-6">
            <div className="bg-darker p-5 rounded-xl border border-accent/50 flex flex-col flex-1">
              <h4 className="font-bold mb-4 text-accent border-b border-gray-700 pb-2">{t.forecast}</h4>
              <div className="flex-1 min-h-[180px]">
                <Line data={createChartData(chartData14, Array.from({length: 14}, (_, i) => `Day ${i+1}`))} options={chartOptions} />
              </div>
            </div>
            <div className="bg-darker p-5 rounded-xl border border-accent/50 flex flex-col flex-1">
              <h4 className="font-bold mb-4 text-accent border-b border-gray-700 pb-2">{t.trend}</h4>
              <div className="flex-1 min-h-[180px]">
                <Line data={createChartData(chartData5y, ['2022', '2023', '2024', '2025', '2026'])} options={chartOptions} />
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-darker p-5 rounded-xl border border-accent/50">
          <h4 className="font-bold mb-3 text-accent">Ұсыныстар</h4>
          <div className="flex flex-wrap items-center gap-4 text-lg">
            {city.r === 0 && <>🟢 <span>{t.rec_safe}</span></>}
            {city.r === 1 && <>🟡 <span>{t.rec_filter}</span></>}
            {city.r === 2 && (
              <>
                🔴 <span className="text-danger font-bold">{t.rec_boil}</span>
                <span className="text-warning font-bold ml-4">⚠️ {t.rec_kids}</span>
              </>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};
