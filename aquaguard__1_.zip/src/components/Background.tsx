import React, { useEffect, useRef, useImperativeHandle, forwardRef } from 'react';

export interface BackgroundRef {
  triggerRain: () => void;
}

export const Background = forwardRef<BackgroundRef>((props, ref) => {
  const bgCanvasRef = useRef<HTMLCanvasElement>(null);
  const rainCanvasRef = useRef<HTMLCanvasElement>(null);
  const isRainingRef = useRef(false);
  const raindropsRef = useRef<any[]>([]);

  useImperativeHandle(ref, () => ({
    triggerRain: () => {
      if (isRainingRef.current) return;
      isRainingRef.current = true;
      const w = window.innerWidth;
      const h = window.innerHeight;
      // Less intense rain: 35-45 drops
      const dropCount = Math.floor(Math.random() * 10) + 35;
      raindropsRef.current = Array.from({length: dropCount}, () => ({
        x: Math.random() * w, y: Math.random() * -h,
        l: Math.random() * 15 + 10,
        v: Math.random() * 8 + 12
      }));
      // Shorter duration: 1.5s
      setTimeout(() => { isRainingRef.current = false; }, 1500);
    }
  }));

  useEffect(() => {
    const bgCanvas = bgCanvasRef.current;
    const rainCanvas = rainCanvasRef.current;
    if (!bgCanvas || !rainCanvas) return;
    const bgCtx = bgCanvas.getContext('2d');
    const rainCtx = rainCanvas.getContext('2d');
    if (!bgCtx || !rainCtx) return;

    let w = window.innerWidth;
    let h = window.innerHeight;
    bgCanvas.width = rainCanvas.width = w;
    bgCanvas.height = rainCanvas.height = h;

    const handleResize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      bgCanvas.width = rainCanvas.width = w;
      bgCanvas.height = rainCanvas.height = h;
    };
    window.addEventListener('resize', handleResize);

    const particles = Array.from({length: 15}, () => ({
      x: Math.random() * w, y: Math.random() * h,
      r: Math.random() * 3 + 1,
      vx: (Math.random() - 0.5) * 0.5, vy: (Math.random() - 0.5) * 0.5,
      glow: Math.random() * 15 + 5
    }));

    let time = 0;
    let animationFrameId: number;

    const render = () => {
      // Draw BG
      bgCtx.clearRect(0, 0, w, h);
      bgCtx.beginPath();
      for(let x=0; x<=w; x+=10) {
        let y = h - 100 + Math.sin(x * 0.005 + time) * 20 + Math.sin(x * 0.01 - time*1.5) * 10;
        if(x===0) bgCtx.moveTo(x, y); else bgCtx.lineTo(x, y);
      }
      bgCtx.lineTo(w, h); bgCtx.lineTo(0, h);
      bgCtx.fillStyle = 'rgba(0, 48, 135, 0.1)';
      bgCtx.fill();

      particles.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if(p.x < 0 || p.x > w) p.vx *= -1;
        if(p.y < 0 || p.y > h) p.vy *= -1;
        
        bgCtx.beginPath();
        bgCtx.arc(p.x, p.y, p.r, 0, Math.PI*2);
        bgCtx.fillStyle = '#00d4ff';
        bgCtx.shadowBlur = p.glow + Math.sin(time*5)*5;
        bgCtx.shadowColor = '#00d4ff';
        bgCtx.fill();
        bgCtx.shadowBlur = 0;
      });

      // Draw Rain
      rainCtx.clearRect(0, 0, w, h);
      if (isRainingRef.current || raindropsRef.current.length > 0) {
        // Thinner and lighter drops
        rainCtx.strokeStyle = 'rgba(0, 212, 255, 0.3)';
        rainCtx.lineWidth = 1;
        rainCtx.lineCap = 'round';
        rainCtx.shadowBlur = 8;
        rainCtx.shadowColor = '#00d4ff';

        for(let i = raindropsRef.current.length - 1; i >= 0; i--) {
          let r = raindropsRef.current[i];
          rainCtx.beginPath();
          rainCtx.moveTo(r.x, r.y);
          rainCtx.lineTo(r.x, r.y + r.l);
          rainCtx.stroke();
          r.y += r.v;
          if(r.y > h) {
            if(isRainingRef.current) { r.y = -r.l; r.x = Math.random() * w; }
            else { raindropsRef.current.splice(i, 1); }
          }
        }
        rainCtx.shadowBlur = 0;
      }

      time += 0.02;
      animationFrameId = requestAnimationFrame(render);
    };
    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <>
      <canvas ref={bgCanvasRef} className="fixed top-0 left-0 w-full h-full -z-10 pointer-events-none" />
      <canvas ref={rainCanvasRef} className="fixed top-0 left-0 w-full h-full z-[9999] pointer-events-none" />
    </>
  );
});
