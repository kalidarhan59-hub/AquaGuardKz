export interface City {
  id: number;
  n: string;
  region: string;
  pop: string;
  desc: string;
  lat: number;
  lng: number;
  r: number; // 0: success, 1: warning, 2: danger
  isMain: boolean;
  links?: {
    official?: string;
    wiki?: string;
    meteo?: string;
  };
}

const rawCities = [
  { n: "Ақтөбе облысы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/aktobe?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Ақтөбе_облысы", meteo: "https://www.kazhydromet.kz/klimat/klimat-kazahstana-po-oblastyam", lat: 50.283, lng: 57.167, isMain: true },
  { n: "Ақтөбе қаласы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/aktobe-akt?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Ақтөбе", meteo: "https://www.kazhydromet.kz/klimat/aktobe", lat: 50.283, lng: 57.167, isMain: false },
  { n: "Мұғалжар ауданы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/mugalzhar?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Мұғалжар_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 48.8, lng: 58.0, isMain: false },
  { n: "Қандыағаш қаласы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/kandyagash?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Қандыағаш", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 49.4743, lng: 57.4242, isMain: false },
  { n: "Сағашилі ауылы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/mugalzhar?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Сағашилі", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 49.2667, lng: 57.4667, isMain: false },
  { n: "Алға ауданы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/alga?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Алға_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 49.9, lng: 57.3, isMain: false },
  { n: "Әйтеке би ауданы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "http://aitekebi.aktobe.gov.kz", wiki: "https://kk.wikipedia.org/wiki/Әйтеке_би_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 50.0, lng: 60.5, isMain: false },
  { n: "Байғанин ауданы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/bajganin?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Байғанин_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 47.5, lng: 56.0, isMain: false },
  { n: "Ырғыз ауданы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/irgiz?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Ырғыз_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 48.6, lng: 61.2, isMain: false },
  { n: "Мәртөк ауданы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/martuk?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Мәртөк_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 50.7, lng: 56.5, isMain: false },
  { n: "Темір ауданы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/temir?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Темір_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 49.1, lng: 56.1, isMain: false },
  { n: "Ойыл ауданы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/ojyl?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Ойыл_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 49.3, lng: 54.7, isMain: false },
  { n: "Хромтау ауданы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/hromtau?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Хромтау_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 50.2, lng: 58.4, isMain: false },
  { n: "Шалқар ауданы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/shalkar?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Шалқар_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 47.8, lng: 59.6, isMain: false },
  { n: "Қарғалы ауданы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/kargaly?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Қарғалы_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 50.8, lng: 57.8, isMain: false },
  { n: "Қобда ауданы", region: "АҚТӨБЕ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/kobda?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Қобда_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 50.1, lng: 55.6, isMain: false },

  { n: "Абай облысы", region: "АБАЙ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/abai?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Абай_облысы", meteo: "https://www.kazhydromet.kz/klimat/klimat-kazahstana-po-oblastyam", lat: 50.411, lng: 80.227, isMain: true },
  { n: "Семей қаласы", region: "АБАЙ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/semey?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Семей", meteo: "https://www.kazhydromet.kz/klimat/semej", lat: 50.411, lng: 80.227, isMain: false },
  { n: "Абай ауданы", region: "АБАЙ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/abai-abairayon?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Абай_ауданы_(Абай_облысы)", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/2/0", lat: 49.0, lng: 79.5, isMain: false },
  { n: "Аягөз ауданы", region: "АБАЙ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/ayagoz?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Аягөз_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/2/0", lat: 47.9, lng: 80.4, isMain: false },
  { n: "Бесқарағай ауданы", region: "АБАЙ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/beskaragay?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Бесқарағай_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/2/0", lat: 50.9, lng: 79.4, isMain: false },
  { n: "Бородулиха ауданы", region: "АБАЙ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/borodulikha?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Бородулиха_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/2/0", lat: 50.8, lng: 81.1, isMain: false },
  { n: "Жарма ауданы", region: "АБАЙ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/zharma?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Жарма_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/2/0", lat: 49.2, lng: 81.2, isMain: false },
  { n: "Үржар ауданы", region: "АБАЙ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/urzhar?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Үржар_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/2/0", lat: 47.0, lng: 81.6, isMain: false },

  { n: "Ақмола облысы", region: "АҚМОЛА ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/akmola?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Ақмола_облысы", meteo: "https://www.kazhydromet.kz/klimat/klimat-kazahstana-po-oblastyam", lat: 53.283, lng: 69.383, isMain: true },
  { n: "Көкшетау қаласы", region: "АҚМОЛА ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/kokshetau?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Көкшетау", meteo: "https://www.kazhydromet.kz/klimat/kokshetau", lat: 53.283, lng: 69.383, isMain: false },
  { n: "Аршалы ауданы", region: "АҚМОЛА ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/arshaly?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Аршалы_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/3/0", lat: 50.8, lng: 72.1, isMain: false },
  { n: "Астрахан ауданы", region: "АҚМОЛА ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/astrahan?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Астрахан_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/3/0", lat: 51.5, lng: 69.7, isMain: false },
  { n: "Атбасар ауданы", region: "АҚМОЛА ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/atbasar?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Атбасар_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/3/0", lat: 51.8, lng: 68.3, isMain: false },
  { n: "Бурабай ауданы", region: "АҚМОЛА ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/burabay?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Бурабай_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/3/0", lat: 52.9, lng: 70.2, isMain: false },
  { n: "Целиноград ауданы", region: "АҚМОЛА ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/celinograd?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Целиноград_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/3/0", lat: 51.1, lng: 71.0, isMain: false },
  { n: "Шортанды ауданы", region: "АҚМОЛА ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/shortandy?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Шортанды_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/3/0", lat: 51.7, lng: 71.0, isMain: false },

  { n: "Алматы облысы", region: "АЛМАТЫ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/almaty?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Алматы_облысы", meteo: "https://www.kazhydromet.kz/klimat/klimat-kazahstana-po-oblastyam", lat: 43.883, lng: 77.083, isMain: true },
  { n: "Қонаев қаласы", region: "АЛМАТЫ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/konaev?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Қонаев", meteo: "https://www.kazhydromet.kz/klimat/konaev", lat: 43.883, lng: 77.083, isMain: false },
  { n: "Іле ауданы", region: "АЛМАТЫ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/ile?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Іле_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/4/0", lat: 43.6, lng: 76.9, isMain: false },
  { n: "Талғар ауданы", region: "АЛМАТЫ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/talgar?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Талғар_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/4/0", lat: 43.3, lng: 77.2, isMain: false },
  { n: "Еңбекшіқазақ ауданы", region: "АЛМАТЫ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/enbekshikazakh?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Еңбекшіқазақ_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/4/0", lat: 43.3, lng: 77.8, isMain: false },
  { n: "Қарасай ауданы", region: "АЛМАТЫ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/karasai?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Қарасай_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/4/0", lat: 43.2, lng: 76.6, isMain: false },
  { n: "Жамбыл ауданы", region: "АЛМАТЫ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/zhambyl-almaty?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Жамбыл_ауданы_(Алматы_облысы)", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/4/0", lat: 43.1, lng: 76.2, isMain: false },

  { n: "Атырау облысы", region: "АТЫРАУ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/atyrau?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Атырау_облысы", meteo: "https://www.kazhydromet.kz/klimat/klimat-kazahstana-po-oblastyam", lat: 47.116, lng: 51.883, isMain: true },
  { n: "Атырау қаласы", region: "АТЫРАУ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/atyrau-akt?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Атырау", meteo: "https://www.kazhydromet.kz/klimat/atyrau", lat: 47.116, lng: 51.883, isMain: false },
  { n: "Жылыой ауданы", region: "АТЫРАУ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/zhylyoi?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Жылыой_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 46.9, lng: 54.0, isMain: false },
  { n: "Индер ауданы", region: "АТЫРАУ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/inder?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Индер_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 48.5, lng: 51.7, isMain: false },
  { n: "Махамбет ауданы", region: "АТЫРАУ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/makhambyet?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Махамбет_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 47.6, lng: 51.5, isMain: false },
  { n: "Құрманғазы ауданы", region: "АТЫРАУ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/kurmangazy?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Құрманғазы_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/5/0", lat: 46.6, lng: 49.2, isMain: false },

  { n: "Батыс Қазақстан облысы", region: "БАТЫС ҚАЗАҚСТАН ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/bko?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Батыс_Қазақстан_облысы", meteo: "https://www.kazhydromet.kz/klimat/klimat-kazahstana-po-oblastyam", lat: 51.233, lng: 51.366, isMain: true },
  { n: "Орал қаласы", region: "БАТЫС ҚАЗАҚСТАН ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/oral?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Орал", meteo: "https://www.kazhydromet.kz/klimat/oral", lat: 51.233, lng: 51.366, isMain: false },
  { n: "Бөрлі ауданы", region: "БАТЫС ҚАЗАҚСТАН ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/burlin?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Бөрлі_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/7/0", lat: 51.1, lng: 52.9, isMain: false },
  { n: "Бәйтерек ауданы", region: "БАТЫС ҚАЗАҚСТАН ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/bayterek?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Бәйтерек_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/7/0", lat: 51.5, lng: 51.0, isMain: false },
  { n: "Теректі ауданы", region: "БАТЫС ҚАЗАҚСТАН ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/terekty?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Теректі_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/7/0", lat: 51.0, lng: 52.0, isMain: false },

  { n: "Жамбыл облысы", region: "ЖАМБЫЛ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/zhambyl?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Жамбыл_облысы", meteo: "https://www.kazhydromet.kz/klimat/klimat-kazahstana-po-oblastyam", lat: 42.900, lng: 71.366, isMain: true },
  { n: "Тараз қаласы", region: "ЖАМБЫЛ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/taraz?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Тараз", meteo: "https://www.kazhydromet.kz/klimat/taraz", lat: 42.900, lng: 71.366, isMain: false },
  { n: "Байзақ ауданы", region: "ЖАМБЫЛ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/baizak?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Байзақ_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/8/0", lat: 43.0, lng: 71.5, isMain: false },
  { n: "Қордай ауданы", region: "ЖАМБЫЛ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/korday?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Қордай_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/8/0", lat: 43.3, lng: 74.7, isMain: false },
  { n: "Шу ауданы", region: "ЖАМБЫЛ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/shu?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Шу_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/8/0", lat: 43.6, lng: 73.7, isMain: false },

  { n: "Қарағанды облысы", region: "ҚАРАҒАНДЫ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/karaganda?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Қарағанды_облысы", meteo: "https://www.kazhydromet.kz/klimat/karaganda", lat: 49.801, lng: 73.102, isMain: true },
  { n: "Қарағанды қаласы", region: "ҚАРАҒАНДЫ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/karaganda-akt?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Қарағанды", meteo: "https://www.kazhydromet.kz/klimat/karaganda", lat: 49.801, lng: 73.102, isMain: false },
  { n: "Бұқар Жырау ауданы", region: "ҚАРАҒАНДЫ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/bukhar-zhyrau?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Бұқар_Жырау_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/9/0", lat: 50.1, lng: 73.5, isMain: false },
  { n: "Абай ауданы", region: "ҚАРАҒАНДЫ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/abai-karaganda?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Абай_ауданы_(Қарағанды_облысы)", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/9/0", lat: 49.6, lng: 72.8, isMain: false },
  { n: "Осакаровка ауданы", region: "ҚАРАҒАНДЫ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/osakarovka?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Осакаровка_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/9/0", lat: 50.5, lng: 72.6, isMain: false },

  { n: "Қостанай облысы", region: "ҚОСТАНАЙ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/kostanay?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Қостанай_облысы", meteo: "https://www.kazhydromet.kz/klimat/kostanaj", lat: 53.216, lng: 63.633, isMain: true },
  { n: "Қостанай қаласы", region: "ҚОСТАНАЙ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/kostanay-akt?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Қостанай", meteo: "https://www.kazhydromet.kz/klimat/kostanaj", lat: 53.216, lng: 63.633, isMain: false },
  { n: "Арқалық қаласы", region: "ҚОСТАНАЙ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/arkalyk?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Арқалық", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/10/0", lat: 50.2, lng: 66.9, isMain: false },
  { n: "Рудный қаласы", region: "ҚОСТАНАЙ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/rudny?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Рудный", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/10/0", lat: 52.9, lng: 63.1, isMain: false },
  { n: "Әулиекөл ауданы", region: "ҚОСТАНАЙ ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/auliekol?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Әулиекөл_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/10/0", lat: 52.3, lng: 64.1, isMain: false },

  { n: "Түркістан облысы", region: "ТҮРКІСТАН ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/turkistan?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Түркістан_облысы", meteo: "https://www.kazhydromet.kz/klimat/klimat-kazahstana-po-oblastyam", lat: 43.300, lng: 68.240, isMain: true },
  { n: "Түркістан қаласы", region: "ТҮРКІСТАН ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/turkistan-akt?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Түркістан", meteo: "https://www.kazhydromet.kz/klimat/turkistan", lat: 43.300, lng: 68.240, isMain: false },
  { n: "Сайрам ауданы", region: "ТҮРКІСТАН ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/sairam?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Сайрам_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/15/0", lat: 42.3, lng: 69.7, isMain: false },
  { n: "Сарыағаш ауданы", region: "ТҮРКІСТАН ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/saryagash?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Сарыағаш_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/15/0", lat: 41.4, lng: 69.1, isMain: false },
  { n: "Жетісай ауданы", region: "ТҮРКІСТАН ОБЛЫСЫ", official: "https://www.gov.kz/memleket/entities/zhetysai?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Жетісай_ауданы", meteo: "https://www.kazhydromet.kz/weather/in_city_7_days/15/0", lat: 40.7, lng: 68.3, isMain: false },

  { n: "Астана", region: "РЕСПУБЛИКАЛЫҚ МАҢЫЗЫ БАР ҚАЛАЛАР", official: "https://www.gov.kz/memleket/entities/astana?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Астана", meteo: "https://www.kazhydromet.kz/klimat/nur-sultan", lat: 51.169, lng: 71.449, isMain: true },
  { n: "Алматы", region: "РЕСПУБЛИКАЛЫҚ МАҢЫЗЫ БАР ҚАЛАЛАР", official: "https://www.gov.kz/memleket/entities/almaty-akt?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Алматы", meteo: "https://www.kazhydromet.kz/klimat/almaty", lat: 43.222, lng: 76.851, isMain: true },
  { n: "Шымкент", region: "РЕСПУБЛИКАЛЫҚ МАҢЫЗЫ БАР ҚАЛАЛАР", official: "https://www.gov.kz/memleket/entities/shymkent?lang=kk", wiki: "https://kk.wikipedia.org/wiki/Шымкент", meteo: "https://www.kazhydromet.kz/klimat/shymkent", lat: 42.341, lng: 69.590, isMain: true }
];

export const cities: City[] = rawCities.map((rc, idx) => {
  return {
    id: idx,
    n: rc.n,
    region: rc.region,
    pop: Math.floor(Math.random() * 500000 + 10000).toString(),
    desc: `${rc.n} - ${rc.region} аумағында орналасқан.`,
    lat: rc.lat,
    lng: rc.lng,
    r: Math.random() > 0.7 ? 1 : 0,
    isMain: rc.isMain,
    links: {
      official: rc.official,
      wiki: rc.wiki,
      meteo: rc.meteo
    }
  };
});
