export const i18n = {
  kz: {
    nav_home: "Басты бет", nav_map: "Карта", nav_cities: "Облыстар", nav_about: "О проекте", nav_contact: "Байланыс",
    report: "Мәселе туралы хабарлау", title: "Қазақстанның су сапасын бақылау", slogan: "AquaGuard KZ: Су бақылауда — ұлт денсаулығы қауіпсіздікте",
    subtitle: "Нақты уақыт режиміндегі экологиялық мониторинг және болжам", btn_map: "Картаны ашу", btn_search: "Қаланы іздеу",
    search_ph: "Қаланы енгізіңіз...", norm: "Норма", warn: "Назар аударыңыз", danger: "Қауіпті", cities_title: "Облыстар",
    about_title: "Жоба туралы", about_text1: "AquaGuard KZ — Қазақстан Республикасындағы су сапасын бақылауға арналған инновациялық платформа.",
    about_text2: "Біз нақты ақпарат пен 14 күндік болжамдарды ұсыну үшін жүздеген IoT датчиктерінің деректерін, спутниктік суреттерді және машиналық оқыту алгоритмдерін біріктіреміз.",
    about_text3: "Біздің миссиямыз – әрбір азаматты ауыз судың сапасы туралы сенімді ақпаратпен қамтамасыз ету және экологиялық апаттардың алдын алу.",
    contact_title: "Байланыс", contact_text: "Бізбен байланысыңыз",
    param_nh4: "Аммоний", param_no3: "Нитраттар", param_fe: "Темір", param_hard: "Қаттылық", param_ph: "pH", param_turb: "Лайлылық", param_mic: "Микробиология",
    forecast: "Болжам (14 күн)", trend: "Тренд (5 жыл)", rec_boil: "Суды қайнату керек", rec_filter: "Сүзгіні орнатыңыз", rec_safe: "Су ішуге қауіпсіз", rec_kids: "Балаларға пайдаланбаңыз",
    region: "Облыс", population: "Халық саны", desc: "Сипаттама",
    footer_privacy: "Құпиялылық саясаты", footer_terms: "Қолдану шарттары", footer_rights: "Барлық құқықтар қорғалған."
  },
  ru: {
    nav_home: "Главная", nav_map: "Карта", nav_cities: "Области", nav_about: "О проекте", nav_contact: "Контакты",
    report: "Сообщить о проблеме", title: "Контроль качества воды Казахстана", slogan: "AquaGuard KZ: Вода под контролем — здоровье нации в безопасности",
    subtitle: "Экологический мониторинг и прогнозирование в реальном времени", btn_map: "Открыть карту", btn_search: "Поиск по городу",
    search_ph: "Введите город...", norm: "Норма", warn: "Внимание", danger: "Опасно", cities_title: "Области",
    about_title: "О проекте", about_text1: "AquaGuard KZ — инновационная платформа для мониторинга качества воды в Республике Казахстан.",
    about_text2: "Мы объединяем данные с сотен IoT-датчиков, спутниковые снимки и алгоритмы машинного обучения для предоставления точной информации и прогнозов на 14 дней.",
    about_text3: "Наша миссия — обеспечить каждого гражданина достоверной информацией о качестве питьевой воды и предотвратить экологические катастрофы.",
    contact_title: "Контакты", contact_text: "Свяжитесь с нами",
    param_nh4: "Аммоний", param_no3: "Нитраты", param_fe: "Железо", param_hard: "Жесткость", param_ph: "pH", param_turb: "Мутность", param_mic: "Микробиология",
    forecast: "Прогноз (14 дней)", trend: "Тренд (5 лет)", rec_boil: "Воду нужно кипятить", rec_filter: "Установите фильтр", rec_safe: "Вода безопасна для питья", rec_kids: "Не использовать для детей",
    region: "Область", population: "Население", desc: "Описание",
    footer_privacy: "Политика конфиденциальности", footer_terms: "Условия использования", footer_rights: "Все права защищены."
  },
  en: {
    nav_home: "Home", nav_map: "Map", nav_cities: "Regions", nav_about: "About", nav_contact: "Contact",
    report: "Report issue", title: "Kazakhstan Water Quality Control", slogan: "AquaGuard KZ: Water under control — health of the nation in safety",
    subtitle: "Real-time environmental monitoring and forecasting", btn_map: "Open map", btn_search: "Search city",
    search_ph: "Enter city...", norm: "Normal", warn: "Warning", danger: "Danger", cities_title: "Regions",
    about_title: "About Project", about_text1: "AquaGuard KZ is an innovative platform for water quality monitoring in the Republic of Kazakhstan.",
    about_text2: "We combine data from hundreds of IoT sensors, satellite imagery, and machine learning algorithms to provide accurate information and 14-day forecasts.",
    about_text3: "Our mission is to provide every citizen with reliable information about drinking water quality and prevent environmental disasters.",
    contact_title: "Contact", contact_text: "Get in touch with us",
    param_nh4: "Ammonium", param_no3: "Nitrates", param_fe: "Iron", param_hard: "Hardness", param_ph: "pH", param_turb: "Turbidity", param_mic: "Microbiology",
    forecast: "Forecast (14 days)", trend: "Trend (5 years)", rec_boil: "Water must be boiled", rec_filter: "Install a filter", rec_safe: "Water is safe to drink", rec_kids: "Do not use for children",
    region: "Region", population: "Population", desc: "Description",
    footer_privacy: "Privacy Policy", footer_terms: "Terms of Service", footer_rights: "All rights reserved."
  }
};

export type Lang = 'kz' | 'ru' | 'en';
